document.getElementById("idCardForm").addEventListener("submit", function(e) {
    e.preventDefault();
    var name = document.getElementById("name").value;
    var college = document.getElementById("college").value;
    var location = document.getElementById("location").value;

    var cardContent = document.getElementById("cardContent");
    cardContent.innerHTML = ""; 

    var nameElement = document.createElement("p");
    nameElement.textContent = " Name: " + name;
    cardContent.appendChild(nameElement);

    var collegeElement = document.createElement("p");
    collegeElement.textContent = " College Name: " + college;
    cardContent.appendChild(collegeElement);

    var locationElement = document.createElement("p");
    locationElement.textContent = " Location: " + location;
    cardContent.appendChild(locationElement);

    imgDisplayed.style.display="block";
    var idCard = document.getElementById("idCard");
    idCard.style.display = "block";
    
});
var button=document.getElementById("Generate");
    var images=document.getElementById("imgDisplayed");
    button.addEventListener("click",function()
    {
       
        var img = document.getElementById("image").files[0];
        images.src=URL.createObjectURL(img);
        
    });